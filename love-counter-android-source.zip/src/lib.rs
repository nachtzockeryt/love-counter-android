use chrono::{DateTime, Datelike, Months, NaiveDate, NaiveDateTime, TimeZone, Timelike, Utc};
use chrono_tz::Tz;
use eframe::egui::{self, Color32, FontFamily, FontId, RichText, TextStyle};
use std::{path::PathBuf, time::Duration};

const PINK: Color32 = Color32::from_rgb(246, 246, 246);
const BG: Color32 = Color32::from_rgb(8, 8, 8);
const MUTED: Color32 = Color32::from_rgb(145, 145, 145);
const INK: Color32 = Color32::from_rgb(246, 246, 246);

#[no_mangle]
fn android_main(app: winit::platform::android::activity::AndroidApp) {
    android_logger::init_once(
        android_logger::Config::default().with_max_level(log::LevelFilter::Info),
    );

    // Hier wird das Startdatum gespeichert
    let save_path = app.internal_data_path().map(|p| p.join("start.txt"));

    let options = eframe::NativeOptions {
        android_app: Some(app),
        ..Default::default()
    };

    eframe::run_native(
        "Love Counter",
        options,
        Box::new(move |cc| Ok(Box::new(LoveCounter::new(cc, save_path)))),
    )
    .unwrap();
}

// Zeitzone des Handys. Fallback: Berlin.
fn local_tz() -> Tz {
    iana_time_zone::get_timezone()
        .ok()
        .and_then(|name| name.parse::<Tz>().ok())
        .unwrap_or(chrono_tz::Europe::Berlin)
}

#[derive(Default)]
struct Elapsed {
    years: i64,
    months: i64,
    days: i64,
    hours: i64,
    minutes: i64,
    seconds: i64,
    total_years: f64,
    total_months: i64,
    total_days: i64,
    total_hours: i64,
    total_minutes: i64,
    total_seconds: i64,
}

fn compute(start: DateTime<Tz>, now: DateTime<Tz>) -> Elapsed {
    if start >= now {
        return Elapsed::default();
    }

    let s = start.naive_local();
    let n = now.naive_local();
    let mut total_months =
        (n.year() - s.year()) as i64 * 12 + n.month() as i64 - s.month() as i64;
    if total_months < 0 {
        total_months = 0;
    }

    // volle Monate finden, die noch nicht in der Zukunft liegen
    let mut base = start;
    while total_months > 0 {
        match start.checked_add_months(Months::new(total_months as u32)) {
            Some(b) if b <= now => {
                base = b;
                break;
            }
            _ => total_months -= 1,
        }
    }

    let rest = now.signed_duration_since(base);
    let total = now.signed_duration_since(start);

    Elapsed {
        years: total_months / 12,
        months: total_months % 12,
        days: rest.num_days(),
        hours: rest.num_hours() % 24,
        minutes: rest.num_minutes() % 60,
        seconds: rest.num_seconds() % 60,
        total_years: total.num_seconds() as f64 / 31_556_952.0,
        total_months,
        total_days: total.num_days(),
        total_hours: total.num_hours(),
        total_minutes: total.num_minutes(),
        total_seconds: total.num_seconds(),
    }
}

// 1234567 -> "1,234,567"
fn group_digits(n: i64) -> String {
    let s = n.to_string();
    let mut out = String::new();
    for (i, c) in s.chars().rev().enumerate() {
        if i > 0 && i % 3 == 0 {
            out.push(',');
        }
        out.push(c);
    }
    out.chars().rev().collect()
}

struct EditFields {
    day: i32,
    month: i32,
    year: i32,
    hour: i32,
    minute: i32,
}

impl EditFields {
    fn from_naive(n: NaiveDateTime) -> Self {
        Self {
            day: n.day() as i32,
            month: n.month() as i32,
            year: n.year(),
            hour: n.hour() as i32,
            minute: n.minute() as i32,
        }
    }
}

struct LoveCounter {
    tz: Tz,
    start: Option<DateTime<Tz>>,
    save_path: Option<PathBuf>,
    show_total: [bool; 6],
    editing: bool,
    edit: EditFields,
    error: Option<String>,
}

impl LoveCounter {
    fn new(cc: &eframe::CreationContext<'_>, save_path: Option<PathBuf>) -> Self {
        // Minimalistisches dunkles Design.
        let mut v = egui::Visuals::dark();
        v.panel_fill = BG;
        v.override_text_color = Some(INK);
        v.selection.bg_fill = Color32::from_rgb(74, 74, 74);
        v.widgets.inactive.weak_bg_fill = Color32::from_rgb(23, 23, 23);
        v.widgets.hovered.weak_bg_fill = Color32::from_rgb(40, 40, 40);
        v.widgets.active.weak_bg_fill = Color32::from_rgb(58, 58, 58);
        cc.egui_ctx.set_visuals(v);
        cc.egui_ctx.style_mut(|s| {
            s.text_styles.insert(TextStyle::Body, FontId::new(17.0, FontFamily::Proportional));
            s.text_styles.insert(TextStyle::Button, FontId::new(17.0, FontFamily::Proportional));
            s.spacing.item_spacing = egui::vec2(10.0, 12.0);
        });

        let tz = local_tz();

        // gespeichertes Startdatum laden
        let loaded = save_path
            .as_ref()
            .and_then(|p| std::fs::read_to_string(p).ok())
            .and_then(|t| NaiveDateTime::parse_from_str(t.trim(), "%Y-%m-%d %H:%M").ok());

        let (start, editing, edit) = match loaded {
            Some(naive) => (
                tz.from_local_datetime(&naive).earliest(),
                false,
                EditFields::from_naive(naive),
            ),
            None => {
                let today = Utc::now()
                    .with_timezone(&tz)
                    .date_naive()
                    .and_hms_opt(0, 0, 0)
                    .unwrap();
                let start = tz.from_local_datetime(&today).earliest();
                if start.is_some() {
                    if let Some(path) = &save_path {
                        let _ = std::fs::write(path, today.format("%Y-%m-%d %H:%M").to_string());
                    }
                }
                (start, false, EditFields::from_naive(today))
            }
        };

        Self {
            tz,
            start,
            save_path,
            show_total: [false; 6],
            editing,
            edit,
            error: None,
        }
    }

    fn try_save(&mut self) {
        let naive = NaiveDate::from_ymd_opt(
            self.edit.year,
            self.edit.month as u32,
            self.edit.day as u32,
        )
        .and_then(|d| d.and_hms_opt(self.edit.hour as u32, self.edit.minute as u32, 0));

        let Some(naive) = naive else {
            self.error = Some("Invalid date (for example, February 31).".into());
            return;
        };
        let Some(dt) = self.tz.from_local_datetime(&naive).earliest() else {
            self.error = Some("This local time does not exist because of a clock change.".into());
            return;
        };
        if dt > Utc::now().with_timezone(&self.tz) {
            self.error = Some("The date cannot be in the future.".into());
            return;
        }

        self.start = Some(dt);
        if let Some(p) = &self.save_path {
            let _ = std::fs::write(p, naive.format("%Y-%m-%d %H:%M").to_string());
        }
        self.error = None;
        self.editing = false;
    }

    fn show_counter(&mut self, ui: &mut egui::Ui) {
        let start = self.start.unwrap_or_else(|| {
            let now = Utc::now().with_timezone(&self.tz);
            let midnight = now.date_naive().and_hms_opt(0, 0, 0).unwrap();
            self.tz.from_local_datetime(&midnight).earliest().unwrap_or(now)
        });
        let now = Utc::now().with_timezone(&self.tz);
        let el = compute(start, now);

        ui.vertical_centered(|ui| {
            ui.horizontal(|ui| {
                ui.label(RichText::new("♥").size(20.0).color(INK));
                ui.label(RichText::new("Together since").size(18.0).strong().color(INK));
                ui.label(RichText::new("♥").size(20.0).color(INK));
            });
            ui.label(RichText::new(start.format("%b %d, %Y").to_string()).size(12.0).color(MUTED));
        });
        ui.add_space(18.0);

        let units: [(&str, String, String); 6] = [
            (
                "Year",
                el.years.to_string(),
                format!("{:.2}", el.total_years),
            ),
            ("Month", el.months.to_string(), group_digits(el.total_months)),
            ("Day", el.days.to_string(), group_digits(el.total_days)),
            ("Hour", el.hours.to_string(), group_digits(el.total_hours)),
            ("Minute", el.minutes.to_string(), group_digits(el.total_minutes)),
            ("Second", el.seconds.to_string(), group_digits(el.total_seconds)),
        ];

        let visible_units: Vec<usize> = if el.years > 0 { vec![0, 1, 2, 3, 4, 5] } else { vec![1, 2, 3, 4, 5] };
        ui.vertical_centered(|ui| {
            for i in visible_units {
                let (label, normal, total) = &units[i];
                let shown = if self.show_total[i] { total } else { normal };
                let unit = if shown == "1" {
                    *label
                } else {
                    match *label {
                        "Year" => "Years",
                        "Month" => "Months",
                        "Day" => "Days",
                        "Hour" => "Hours",
                        "Minute" => "Minutes",
                        "Second" => "Seconds",
                        _ => *label,
                    }
                };
                let response = ui.add(
                    egui::Label::new(RichText::new(format!("{} {}", shown, unit)).size(27.0).color(INK))
                        .sense(egui::Sense::click()),
                );
                if response.clicked() { self.show_total[i] = !self.show_total[i]; }
                ui.add_space(4.0);
            }
        });
        ui.add_space(12.0);
        ui.vertical_centered(|ui| {
            ui.label(RichText::new("ⓘ   TIP   ⓘ").size(14.0).strong().color(INK));
            ui.label(RichText::new("Tap a value to see the total count.").size(13.0).color(MUTED));
            ui.label(RichText::new("Change the start date using the button above.").size(12.0).color(MUTED));
        });
    }

    fn show_editor(&mut self, ui: &mut egui::Ui) {
        ui.vertical_centered(|ui| {
            ui.label(RichText::new("YOUR STORY").size(12.0).strong().color(PINK));
            ui.add_space(4.0);
            ui.label(RichText::new("When did it all\nbegin?").size(25.0).strong().color(INK));
            ui.label(RichText::new("Choose your date and time.").size(14.0).color(MUTED));
        });
        ui.add_space(20.0);

        field(ui, "Day", &mut self.edit.day, 1, 31);
        field(ui, "Month", &mut self.edit.month, 1, 12);
        field(ui, "Year", &mut self.edit.year, 1950, 2100);
        field(ui, "Hour", &mut self.edit.hour, 0, 23);
        field(ui, "Minute", &mut self.edit.minute, 0, 59);

        if let Some(err) = &self.error {
            ui.label(RichText::new(err.as_str()).color(Color32::LIGHT_RED));
        }

        ui.add_space(10.0);
        let save = egui::Button::new(RichText::new("Save").strong().color(Color32::WHITE)).fill(PINK);
        if ui.add_sized([ui.available_width(), 52.0], save).clicked() {
            self.try_save();
        }
        if self.start.is_some()
            && ui
                .add_sized([ui.available_width(), 46.0], egui::Button::new("Cancel"))
                .clicked()
        {
            self.editing = false;
            self.error = None;
        }
    }
}

// Zeile mit  [-]  Wert  [+]  (Tippen aufs Handy-Keyboard ist bei egui auf Android hakelig)
fn field(ui: &mut egui::Ui, label: &str, value: &mut i32, min: i32, max: i32) {
    ui.horizontal(|ui| {
        ui.label(RichText::new(label).size(20.0));
        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
            if ui
                .add(egui::Button::new("+").min_size(egui::vec2(56.0, 44.0)))
                .clicked()
            {
                *value = if *value >= max { min } else { *value + 1 };
            }
            ui.label(
                RichText::new(format!("{:02}", *value))
                    .size(24.0)
                    .strong()
                    .color(PINK),
            );
            if ui
                .add(egui::Button::new("−").min_size(egui::vec2(56.0, 44.0)))
                .clicked()
            {
                *value = if *value <= min { max } else { *value - 1 };
            }
        });
    });
}

impl eframe::App for LoveCounter {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        // Sekunden live hochzählen
        ctx.request_repaint_after(Duration::from_millis(100));

        draw_heart_pattern(ctx);
        egui::CentralPanel::default()
            .frame(egui::Frame::new().fill(Color32::TRANSPARENT).inner_margin(egui::Margin::symmetric(20, 18)))
            .show(ctx, |ui| {
                ui.vertical_centered(|ui| {
                    ui.label(RichText::new("♥  Love Counter  ♥").size(18.0).strong().color(INK));
                });
                ui.add_space(6.0);

                if !self.editing
                    && ui.add_sized(
                        [ui.available_width(), 40.0],
                        egui::Button::new(RichText::new("⚙  Change start date").size(14.0).color(INK))
                            .fill(Color32::from_rgb(24, 24, 24)),
                    ).clicked()
                {
                    if let Some(start) = self.start { self.edit = EditFields::from_naive(start.naive_local()); }
                    self.editing = true;
                    self.error = None;
                }

                if self.editing {
                    self.show_editor(ui);
                } else {
                    self.show_counter(ui);
                }
            });
    }
}

fn draw_heart_pattern(ctx: &egui::Context) {
    let painter = ctx.layer_painter(egui::LayerId::background());
    let rect = ctx.screen_rect();
    let hearts = [
        (0.10, 0.13, 62.0), (0.67, 0.11, 53.0), (0.41, 0.30, 44.0),
        (0.88, 0.36, 61.0), (0.13, 0.51, 52.0), (0.64, 0.57, 69.0),
        (0.36, 0.76, 57.0), (0.87, 0.82, 66.0), (0.12, 0.94, 47.0),
    ];
    let stroke = egui::Stroke::new(1.2_f32, Color32::from_rgb(28, 28, 28));
    for (x, y, size) in hearts {
        let center = egui::pos2(rect.left() + rect.width() * x, rect.top() + rect.height() * y);
        let mut points = Vec::with_capacity(49);
        for step in 0..=48 {
            let t = std::f32::consts::TAU * step as f32 / 48.0;
            let sx = 16.0 * t.sin().powi(3);
            let sy = 13.0 * t.cos() - 5.0 * (2.0 * t).cos() - 2.0 * (3.0 * t).cos() - (4.0 * t).cos();
            points.push(egui::pos2(center.x + sx * size / 32.0, center.y - sy * size / 32.0));
        }
        painter.add(egui::Shape::line(points, stroke));
    }
}
